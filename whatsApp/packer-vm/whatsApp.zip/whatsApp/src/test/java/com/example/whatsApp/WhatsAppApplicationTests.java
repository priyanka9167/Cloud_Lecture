package com.example.whatsApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhatsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
