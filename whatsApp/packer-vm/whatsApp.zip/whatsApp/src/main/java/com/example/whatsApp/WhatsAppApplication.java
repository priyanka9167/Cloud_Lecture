package com.example.whatsApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhatsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhatsAppApplication.class, args);
	}

}
